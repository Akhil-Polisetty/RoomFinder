import React from "react";
// import Contact from "../contact/Contact";
import Link from "next/link";
const Navbar = () => {
  return (
    <>
      <div className="w-full flex justify-between gap-2 p-4 text-white bg-cyan-600 cursor-pointer">
        <div className="flex gap-2 ">
        <div>
          <img src="https://th.bing.com/th/id/OIP.45-b1BjHqRqUfiInVhH5oQHaHa?w=165&h=180&c=7&r=0&o=5&dpr=2&pid=1.7" alt="logo" width={30} height={30}/>
        </div>
          <Link href='/'>Rooms4U</Link>
        </div>
        <div className=" flex gap-2">
          <a href="/pages/about">About</a>
          <a href="/pages/contact">Contact</a>
          <a href="/pages/login">Login</a>
        </div>
      </div>
    </>
  );
};

export default Navbar;
