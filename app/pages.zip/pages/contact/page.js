import React from 'react'

const Contact = () => {
  return (
    <>
        Contact Us page
    </>
  )
}

export default Contact