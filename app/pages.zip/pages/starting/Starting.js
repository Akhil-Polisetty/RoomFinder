import React from "react";
import Image from "next/image";
import Link from "next/link";
const Starting = () => {
  return (
    <div className="starti">
      <div className=" flex flex-col justify-center items-center">
        <h1 className="text-center font-bold text-2xl mt-4 flex gap-2">
          Welcome to Rooms4U
          <img
            src="https://th.bing.com/th/id/OIP.45-b1BjHqRqUfiInVhH5oQHaHa?w=165&h=180&c=7&r=0&o=5&dpr=2&pid=1.7"
            alt="logo"
            width={30}
            height={30}
          />
        </h1>
        <h2>Find your perfect rooms here with out need of any broker</h2>
      </div>
      <div className="h-1 bg-red-50 mt-4"></div>
      <div className="about-page">
        <div className="flex gap-8 mt-5 border-2 border-green-200 p-2">
          <img
            src="https://th.bing.com/th/id/OIP.45-b1BjHqRqUfiInVhH5oQHaHa?w=165&h=180&c=7&r=0&o=5&dpr=2&pid=1.7"
            width={225}
            height={225}
            alt=""
          />
          <div className="flex flex-col gap-4 justify-around">
            <div className="text-xl mt-5">
              Add details of the available room or house for rent, including
              property type, location, rent amount, and availability date.
              Highlight key features such as size, furnished status, included
              utilities, and amenities like parking or shared spaces. Mention
              nearby landmarks and any specific rules, like pet or smoking
              policies. Attach clear photos of the property and provide your
              contact details for inquiries, along with terms of the rental
              agreement.
            </div>
            <Link href="/pages/dashboard">
              <button className="hello-b bg-green-500 text-white p-2 rounded-md w-32">
                Create a Room
              </button>
            </Link>
          </div>
        </div>
        <div className="flex gap-8 mt-5 border-2 border-green-200 p-2">
          <img
            src="https://th.bing.com/th/id/OIP.45-b1BjHqRqUfiInVhH5oQHaHa?w=165&h=180&c=7&r=0&o=5&dpr=2&pid=1.7"
            width={225}
            height={225}
            alt=""
          />
          <div className="flex flex-col gap-4 justify-around ">
            <div className="text-xl mt-5">
              Here, you can search for rooms or houses tailored to your
              preferences, including location, type of stay, and budget. Filter
              listings by rent amount, furnished status, and amenities like
              parking or internet. Easily compare options and explore properties
              near key landmarks or transport hubs. Find detailed descriptions,
              photos, and contact details to help you make an informed choice.{" "}
            </div>
            <Link href="/pages/getrooms">
              <button className="hello-b bg-green-500 text-white p-2 rounded-md w-36">
                Search for a room
              </button>
            </Link>
          </div>
        </div>
        <div className="flex gap-8 mt-5 border-2 border-green-200 p-2">
          <img
            src="https://th.bing.com/th/id/OIP.45-b1BjHqRqUfiInVhH5oQHaHa?w=165&h=180&c=7&r=0&o=5&dpr=2&pid=1.7"
            width={225}
            height={225}
            alt=""
          />
          <div className="flex flex-col gap-4 justify-around">
            <div className="text-xl mt-5">
              Here are the rooms you’ve listed for rent, complete with all the
              details provided. You can update any information, such as rent
              amount, availability, or amenities, to keep the listings accurate
              and appealing. Easily edit or remove a room from the list as
              needed. Ensure the details remain up-to-date to attract the right
              tenants quickly.{" "}
            </div>
            <button className="hello-b bg-green-500 text-white p-2 rounded-md w-32">
              Your Rooms
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Starting;
