import React from 'react'

const About = () => {
  return (
   <div>
        About us page
   </div>
  )
}

export default About